package com.track.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.Message
import android.provider.Telephony
import android.util.Log

class SmsReceiver : BroadcastReceiver() {

    private var smsHandlerThread: HandlerThread? = null
    private var smsHandler: Handler? = null

    override fun onReceive(context: Context, intent: Intent) {
        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION == intent.action) {
            if (smsHandlerThread == null) {
                smsHandlerThread = HandlerThread("SmsHandlerThread")
                smsHandlerThread!!.start()
                smsHandler = Handler(smsHandlerThread!!.looper)
            }

            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (message in messages) {
                val sender = message.displayOriginatingAddress
                val messageBody = message.displayMessageBody
                Log.d("SMSReceiver", "Sender: $sender, Message: $messageBody")

                // Process the SMS on a separate thread (SMSHandlerThread)
                smsHandler?.post {
                    // You can process or display the message as needed here.
                    Log.d("messages: ",messages.toString())
                }
            }
        }
    }
}
