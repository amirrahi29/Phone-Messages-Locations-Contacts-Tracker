<?php include('header.php');
if($_GET['main_mobile']){
?>
<link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="card">
            <div class="card-body">
             <form method="POST">
                  <h4 class="card-title"><span>Related Messages<span>&nbsp;&nbsp;&nbsp;<button name="clearBtn" class="btn btn-danger">Clear All</button></span></span></h4>
                  <?php
                     if(isset($_POST['clearBtn'])){
                         $clearAll = "delete FROM all_sms where main_mobile = '$_GET[main_mobile]'";
                         $run_clear = mysqli_query($con,$clearAll);
                         if($run_clear){
                             echo "<script>alert('All messages deleted of ".$_GET['main_mobile']."')</script>";
                             echo "<script>window.open('../../tracker/dashboard.php','_self')</script>";
                         }
                     }
                  ?>
             </form>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th>Id</th>
                            <th>Message Mobile</th>
                            <th>Type</th>
                            <th>Message Date</th>
                            <th>Message</th>
                            <th>Created At</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php
                            $i = 0;
                            $all_sms = "SELECT * FROM all_sms where main_mobile = '$_GET[main_mobile]' order by all_sms_id DESC";
                            $run_all_sms = mysqli_query($con, $all_sms);
                            
                            while ($row = mysqli_fetch_array($run_all_sms)) {
                                $i++;
                            ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $row['message_mobile']; ?></td>
                                    <td><?php echo $row['type']; ?></td>
                                    <td><?php echo $row['message_date']; ?></td>
                                    <td><?php echo $row['message']; ?></td>
                                    <td><?php echo $row['created_date']; ?></td>
                                </tr>
                            <?php } ?>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <script src="vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/data-table.js"></script>
  
  <?php }else{
      echo "<script>window.open('../tracker/dashboard.php','_self')</script>";
  } ?>