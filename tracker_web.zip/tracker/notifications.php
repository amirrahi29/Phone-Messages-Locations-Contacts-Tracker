<?php include('header.php'); ?>
<link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Notifications</h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th>Id</th>
                            <th>Main Mobile</th>
                            <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                           <?php
                           $i = 0;
                            $location = "select * from fcm_token order by fcm_id DESC";
                            $run_location = mysqli_query($con,$location);
                            while($row = mysqli_fetch_array($run_location)){
                                $i++;
                           ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $row['main_mobile']; ?></td>
                            <td><a href="<?php echo "related_notifications.php?main_mobile=".$row['main_mobile']."&&fcm_token=".$row['fcm_token']; ?>" class="btn btn-primary" target="_blank">Send Notifications</a></td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <script src="vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/data-table.js"></script>