<?php include('header.php'); ?>
<link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Last Messages</h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th>Id</th>
                            <th>Main Mobile</th>
                            <th>Message Mobile</th>
                            <th>Type</th>
                            <th>Message</th>
                            <th>Message Date</th>
                            <th>Created At</th>
                        </tr>
                      </thead>
                      <tbody>
                           <?php
                           $i = 0;
                            $last_sms = "select * from last_sms";
                            $run_last_sms = mysqli_query($con,$last_sms);
                            while($row = mysqli_fetch_array($run_last_sms)){
                                $i++;
                           ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $row['main_mobile']; ?></td>
                            <td><?php echo $row['last_sms_mobile']; ?></td>
                            <td><?php echo $row['type']; ?></td>
                            <td><?php echo $row['message']; ?></td>
                            <td><?php echo $row['sms_date']; ?></td>
                            <td><?php echo $row['created_date']; ?></td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <script src="vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/data-table.js"></script>