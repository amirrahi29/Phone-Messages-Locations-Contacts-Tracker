<?php
$con = mysqli_connect("localhost","rojkhtcu_trackeruser","tracker@123","rojkhtcu_tracker");
$fcm_server_key = "AAAAqhlv_sM:APA91bG4sz0pR9oN3Lfrr18pGPY6P5PKbl2KYn5FM8_G7S6QceIdVNyp8--8Mep0aQqIDM-MHszWhS9A6V6vvi3iJg5gyGfqKkfF93l7jtwQgbdVIitpXQiRYTR466ybgFD-qlUX2su0";
?>