<?php include('header.php'); ?>
<link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Call Histories</h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th>Id</th>
                            <th>Main Mobile</th>
                            <th>Total Calls</th>
                            <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php
                            $i = 0;
                            $all_calls = "SELECT DISTINCT main_mobile, MAX(call_history_id) as max_id, name, call_history_number, call_type, call_date, created_date FROM call_histories GROUP BY main_mobile ORDER BY max_id DESC";
                            $run_all_calls = mysqli_query($con, $all_calls);
                            
                            while ($row = mysqli_fetch_array($run_all_calls)) {
                                $i++;
                                $main_mobile = $row['main_mobile'];
                                
                                $getQuery = "SELECT * FROM call_histories WHERE main_mobile = '$main_mobile'";
                                $run_getQuery = mysqli_query($con, $getQuery);
                                $count = mysqli_num_rows($run_getQuery);
                            ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $main_mobile; ?></td>
                                    <td><?php echo $count; ?></td>
                                    <td><a href="<?php echo "related_call_histories.php?main_mobile=".$row['main_mobile']; ?>" class="btn btn-primary" target="_blank">Check</a></td>
                                </tr>
                            <?php } ?>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <script src="vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/data-table.js"></script>