<?php include('header.php');
if($_GET['main_mobile'] && $_GET['fcm_token']){
?>
<link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">
               <form method="POST">
                  <h4 class="card-title">Send Notification</h4>
                  <hr/>
             </form></h4>
              <div class="row">
                <div class="col-12">
                  <form method="POST">
                      <label>Notification Title</label>
                      <input type="text" name="notification_title" class="form-control" required />
                      <br/>
                      <label>Notification Description</label>
                      <input type="text" name="notification_desc" class="form-control" required />
                      <br/>
                      <button class="btn btn-primary" name="notificationBtn">Send</button>
                  </form>
                  <br/>
                  <?php
                      if(isset($_POST['notificationBtn'])){
                          
                          $main_mobile = $_GET['main_mobile'];
                          $fcm_token = $_GET['fcm_token'];
                          $notification_title = $_POST['notification_title'];
                          $notification_desc = $_POST['notification_desc'];
                          
                          //notification start
                            $url = 'https://fcm.googleapis.com/fcm/send';
                            
                            // Notification payload
                            $notification = [
                                'title' => $notification_title,
                                'body' => $notification_desc,
                            ];
                            
                            // Data payload (optional)
                            $data = [
                                'key1' => 'value1',
                                'key2' => 'value2',
                            ];
                            
                            $fields = [
                                'registration_ids' => [$fcm_token],
                                'notification' => $notification,
                                'data' => $data,
                            ];
                            
                            $headers = [
                                'Authorization: key=' . $fcm_server_key,
                                'Content-Type: application/json',
                            ];
                            
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, $url);
                            curl_setopt($ch, CURLOPT_POST, true);
                            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                            $result = curl_exec($ch);
                            
                            if (curl_errno($ch)) {
                                echo 'Curl error: ' . curl_error($ch);
                            } else {
                                $cur_message = json_decode($result);
                                if ($cur_message->success == 1) {
                                    echo 'Notification sent successfully.';
                                } else {
                                    echo 'Token experied for this number!';
                                }
                            }
                            
                            curl_close($ch);
                      }
                  ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <script src="vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/data-table.js"></script>
  
  <?php }else{
      echo "<script>window.open('../tracker/dashboard.php','_self')</script>";
  } ?>