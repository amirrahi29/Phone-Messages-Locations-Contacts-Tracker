<?php
include('../includes/connection.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the expected POST parameters are set
    if (isset($_POST['main_mobile'], $_POST['message'])) {
        // Assuming your $con variable is the connection object
        $main_mobile = $_POST['main_mobile'];
        $message = $_POST['message'];

        // Extract name and mobile from the message
        $matches = array();
        preg_match('/Type: (.+), Mobile: (.+), Message: (.+), Date: (.+)/', $message, $matches);

        // Check if the expected pattern was found in the message
        if (!empty($matches)) {
            $type = $matches[1];  // Adjust index to start from 1
            $message_mobile = $matches[2];
            $message = $matches[3];
            $message_date = $matches[4];

            // Check if main_mobile already exists
            $checkQuery = "SELECT * FROM all_sms WHERE main_mobile = '$main_mobile' && message_mobile = '$message_mobile' && message = '$message'";
            $checkResult = mysqli_query($con, $checkQuery);

            if (mysqli_num_rows($checkResult) > 0) {
                // main_mobile already exists, return an error response
                $response = array("status" => "error", "message" => "Data already exists for main_mobile: $main_mobile");
            } else {
                // main_mobile doesn't exist, proceed with insertion
                $query = "INSERT INTO all_sms(main_mobile, type, message_mobile, message, message_date, created_date) VALUES ('$main_mobile', '$type', '$message_mobile', '$message', '$message_date', NOW())";
                $result = mysqli_query($con, $query);

                // Check if the query was successful
                if ($result) {
                    $response = array("status" => "success", "message" => "Data inserted successfully");
                } else {
                    $response = array("status" => "error", "message" => "Something went wrong: " . mysqli_error($con));
                }
            }
        } else {
            // If the expected pattern was not found in the message, return an error response
            $response = array("status" => "error", "message" => "Invalid message format");
        }

        // Send the JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // If the expected POST parameters are not set, return an error response
        $response = array("status" => "error", "message" => "Missing required parameters");
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // If the request is not a POST request, return an error response
    $response = array("status" => "error", "message" => "Invalid request method");
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
