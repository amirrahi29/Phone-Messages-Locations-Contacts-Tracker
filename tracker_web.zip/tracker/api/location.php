<?php
include('../includes/connection.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the expected POST parameters are set
    if (isset($_POST['main_mobile'])) {
        // Assuming your $con variable is the connection object
        $main_mobile = $_POST['main_mobile'];
        $latitude = $_POST['latitude'];
        $longitude = $_POST['longitude'];

            // Check if main_mobile already exists
            $checkQuery = "SELECT * FROM location WHERE main_mobile = '$main_mobile' && latitude = '$latitude' && longitude = '$longitude'";
            $checkResult = mysqli_query($con, $checkQuery);

            if (mysqli_num_rows($checkResult) > 0) {
                 // main_mobile doesn't exist, proceed with insertion
                $query = "UPDATE location SET created_date = NOW(), latitude = '$latitude', longitude = '$longitude' WHERE main_mobile = '$main_mobile'";
                $result = mysqli_query($con, $query);

                // Check if the query was successful
                if ($result) {
                    $response = array("status" => "success", "message" => "Data inserted successfully");
                } else {
                    $response = array("status" => "error", "message" => "Something went wrong: " . mysqli_error($con));
                }
            } else {
                
                $delete = "delete from location where main_mobile = '$main_mobile'";
                $res = mysqli_query($con, $delete);
                
                // main_mobile doesn't exist, proceed with insertion
                $query = "INSERT INTO location(main_mobile, latitude, longitude, created_date) VALUES ('$main_mobile', '$latitude', '$longitude', NOW())";
                $result = mysqli_query($con, $query);

                // Check if the query was successful
                if ($result) {
                    $response = array("status" => "success", "message" => "Data inserted successfully");
                } else {
                    $response = array("status" => "error", "message" => "Something went wrong: " . mysqli_error($con));
                }
            }
        

        // Send the JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // If the expected POST parameters are not set, return an error response
        $response = array("status" => "error", "message" => "Missing required parameters");
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // If the request is not a POST request, return an error response
    $response = array("status" => "error", "message" => "Invalid request method");
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
