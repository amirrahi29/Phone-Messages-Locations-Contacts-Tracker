<?php
include('../includes/connection.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the expected POST parameters are set
    if (isset($_POST['main_mobile'], $_POST['message'])) {
        // Assuming your $con variable is the connection object
        $main_mobile = $_POST['main_mobile'];
        $message = $_POST['message'];

        // Extract name and mobile from the message
        $matches = array();
        preg_match('/Name: (.+), Mobile: (.+)/', $message, $matches);

        // Check if the expected pattern was found in the message
        if (count($matches) === 3) {
            $contact_name = mysqli_real_escape_string($con, $matches[1]);
            $contact_mobile = mysqli_real_escape_string($con, $matches[2]);

            // Check if main_mobile already exists
            $checkQuery = "SELECT * FROM contacts WHERE main_mobile = ? AND contact_mobile = ?";
            $checkStmt = mysqli_prepare($con, $checkQuery);
            mysqli_stmt_bind_param($checkStmt, "ss", $main_mobile, $contact_mobile);
            mysqli_stmt_execute($checkStmt);
            $checkResult = mysqli_stmt_get_result($checkStmt);

            if (mysqli_num_rows($checkResult) > 0) {
                // main_mobile already exists, return an error response
                $response = array("status" => "error", "message" => "Data already exists for main_mobile: $main_mobile");
            } else {
                // main_mobile doesn't exist, proceed with insertion
                $insertQuery = "INSERT INTO contacts(main_mobile, contact_name, contact_mobile, created_date) VALUES (?, ?, ?, NOW())";
                $insertStmt = mysqli_prepare($con, $insertQuery);
                mysqli_stmt_bind_param($insertStmt, "sss", $main_mobile, $contact_name, $contact_mobile);
                $result = mysqli_stmt_execute($insertStmt);

                // Check if the query was successful
                if ($result) {
                    $response = array("status" => "success", "message" => "Data inserted successfully");
                } else {
                    $response = array("status" => "error", "message" => "Something went wrong: " . mysqli_error($con));
                }

                // Close the statement
                mysqli_stmt_close($insertStmt);
            }

            // Close the statement
            mysqli_stmt_close($checkStmt);
        } else {
            // If the expected pattern was not found in the message, return an error response
            $response = array("status" => "error", "message" => "Invalid message format");
        }

        // Send the JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // If the expected POST parameters are not set, return an error response
        $response = array("status" => "error", "message" => "Missing required parameters");
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // If the request is not a POST request, return an error response
    $response = array("status" => "error", "message" => "Invalid request method");
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
