<?php
include('../includes/connection.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the expected POST parameters are set
    if (isset($_POST['main_mobile'], $_POST['fcm_token'])) {
        // Assuming your $con variable is the connection object
        $main_mobile = $_POST['main_mobile'];
        $fcm_token = $_POST['fcm_token'];
     
            // Check if main_mobile already exists
            $checkQuery = "SELECT * FROM fcm_token WHERE main_mobile = '$main_mobile' && fcm_token = '$fcm_token'";
            $checkResult = mysqli_query($con, $checkQuery);

            if (mysqli_num_rows($checkResult) > 0) {
                // main_mobile already exists, return an error response
                
                $update = "update fcm_token set fcm_token = '$fcm_token' where main_mobile = '$main_mobile'";
                $res = mysqli_query($con,$update);
                
                $response = array("status" => "error", "message" => "Data already exists for main_mobile: $main_mobile");
            } else {
                
                $delete = "delete from fcm_token where main_mobile = '$main_mobile'";
                $res = mysqli_query($con, $delete);
                
                // main_mobile doesn't exist, proceed with insertion
                $query = "INSERT INTO fcm_token(main_mobile, fcm_token, created_date) VALUES ('$main_mobile', '$fcm_token', NOW())";
                $result = mysqli_query($con, $query);

                // Check if the query was successful
                if ($result) {
                    $response = array("status" => "success", "message" => "Data inserted successfully");
                } else {
                    $response = array("status" => "error", "message" => "Something went wrong: " . mysqli_error($con));
                }
            }
       

        // Send the JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // If the expected POST parameters are not set, return an error response
        $response = array("status" => "error", "message" => "Missing required parameters");
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    // If the request is not a POST request, return an error response
    $response = array("status" => "error", "message" => "Invalid request method");
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
